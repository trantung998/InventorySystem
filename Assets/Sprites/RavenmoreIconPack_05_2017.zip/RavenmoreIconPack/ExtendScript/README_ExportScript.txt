Hi,

Pardon my awful programing habits. I've included my export script for this pack. 
To run it you will need Photoshop with "Default" actions from this folder loaded and Adobe's ExtendScript to open and run the JS script file.
By default it requires the following folder structure on drive E:

-RavenmoreIconPack
--512
--256
--128
--64

To change the drive letter just modify the first var - exportFolder

I'd go into more details about this but it's a simple script, and I expect exactly zero people to ever see or use this =)
Have fun!

PS. If you do see this and simplify my brute force approach and encapsulate the functionality into elegant functions let me know. I'd love to credit your talented brain and use your nicer version instead of my crude one.
;)